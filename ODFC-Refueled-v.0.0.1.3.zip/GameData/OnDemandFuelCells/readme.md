# SGEx  
### Proudly Adopts(HOPEFULLY) - for private/personal use  

## ODFC  
### ***On Demand Fuel Cells Refueled (ODFCr)***  

v.0.0.1.2 
   * released:  
   * updated .version to 1.7.3.1 
   * recompiled against Kerbal Space Program 1.7.3 
   * ?  

## Dependencies 
 * 
 * 
 
## Supports 
 * 
 * 
 
## Suggests 
 * 
 * 
 
## License  
![[CC 4.0 BY-NC-SA](https://creativecommons.org/licenses/by-nc-sa/4.0/)](https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png "CC 4.0 BY-NC-SA")

[CC 4.0 BY-NC-SA](https://creativecommons.org/licenses/by-nc-sa/4.0/)

*a part of the **TWYLLTR** (Take What You Like, Leave the Rest) collection.*  
 
📌v1.7.3.1-alpha  
 
## links to original:  
On Demand Fuel Cells (ODFC) by `Orum  
Licensed under CC BY-NC-SA-4.0  
 * ![KSP Forums](https://forum.kerbalspaceprogram.com/index.php?/topic/138431-112-on-demand-fuel-cells-odfc-v11/) 
 * ![Spacedock](https://spacedock.info/mod/618/ODFC%20-%20On%20Demand%20Fuel%20Cells) 
 * ![Dropbox](https://www.dropbox.com/s/0rpp4138jumvaxq/ODFC_v1.1.zip?dl=0) 
 
 
![Jeb's Rule #1"](https://ic.pics.livejournal.com/asaratov/25113347/1448500/1448500_original.jpg   "Jeb's Rule #1") 
 
 
 
##### All bundled mods are distributed under their own licenses
##### All art assets (textures, models, animations) are distributed under an All Rights Reserved License.

###### v1.7.3.1 original: 11 Aug 2018 0K updated: 08 Aug 2019 zed'K
